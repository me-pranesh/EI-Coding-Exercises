public class Obstacle extends Position {
    public Obstacle(int x, int y, Grid grid) {
        super(x, y, Direction.N, grid); // Using Direction.N as a placeholder
    }
}
